* * * PLEASE PAY ATTENTION * * *

In this folder there are all the original files made by Michel Bernard who did the porting.

From the IOS version S220718-R280819 I've added a new Disk Set (Disk Set 3) to support UCSD Pascal natively.

To start UCSD Pascal is not needed anymore to select "Autoboot" in the Z80-MBC2 system menu (as suggested in the original README.TXT file), but just use the option "8" (Change Disk Set) and press any key until the wanted OS name appears (as usual to select the others OSes).

Into the root of the SD the original file AUTOBOOT.BIN is renamed as UCSDLDR.BIN and the disk files as DS3N20.DSK and DS3N21.DSK

Some documentation about UCSD Pascal can be found here: 

http://pascal.hansotten.com/category/ucsd-p-system/

J4F
